<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
	<link rel="stylesheet" href="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://cdn.staticfile.org/jquery/2.1.1/jquery.min.js"></script>
	<script src="https://cdn.staticfile.org/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>男娘大学</title>
	<link rel="stylesheet" href="./static/css/bootstrap.css">
</head>
<body>
 <div class="container">
<div class="row clearfix">
<div id="top">
    <div class="top">
		<div class="col-md-12 column">
        <?php include 'base.php'; ?>
			
			
			<p class="text-center" style="font-size:27px;">
				欢迎来到男娘大学网络课程中心
			</p>
			<p class="text-center" style="font-size:18px;padding:20px">
			男娘大学网络课程中心是一个长期的游戏，你可以其中获得各种各样的性癖开发。你最终将会选择一个或多个专业的课程进行学习，并建立一个每天都有课程表。课程的设计使其不会过多干预您的日常生活，每天只需要10到120分钟的“主动”学习即可。内有许多专业可供选择，每个专业都集中在不同的东西上，如“肛交工程学”，“性别转换学”，“色情心理学”，“公共关系学”和“口交工程学”等专业。此外还有丰富的课程可供选择，比如寸止课程、捆绑课程、灌肠课程、扩张课程、自缚课程、羞辱课程、宠物化课程、女性化课程、高潮训练、感官剥夺 课程、长期贞操等等课程。最棒的是，它完全免费，而且高度可定制。所以报名一个专业，参加一些课程，让旅程开始吧！

所以开始选择一个你喜欢的专业，参加一些课程，开始你的学习之旅吧！！！	
			</p>
			<div class="carousel slide" id="carousel-239139">
				<ol class="carousel-indicators">
					<li data-slide-to="0" data-target="#carousel-239139">
					</li>
					<li data-slide-to="1" data-target="#carousel-239139">
					</li>
					<li data-slide-to="2" data-target="#carousel-239139">
					</li>
					<li data-slide-to="3" data-target="#carousel-239139">
					</li>
				</ol>
				<div class="carousel-inner">
					<div class="item">
						<img alt="" src="./static/img/主页.jpg"/>
					
					</div>
					<div class="item active left">
						<img alt="" src="./static/img/介绍.jpg" />
					
					</div>
					<div class="item next left">
						<img alt="" src="./static/img/sex-page.jpg" />
					
					</div>
					<div class="item right">
						<img alt="" src="./static/img/school-page.jpg" />
					
					</div>
				</div>
				<a class="left carousel-control" href="#carousel-239139" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a> <a class="right carousel-control" href="#carousel-239139" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a>
			</div>
			<div class="container" style = " text-align: center;">
	           <div class="row clearfix">
		            <div class="col-md-12 column">
			          <h2 class="text-center">
					  更新日志:
					  </h2>
					  <p>
					  2019年7月20日：v0.01
					  </p>
					   <p >
					   - 开始码代码
					   </p>
		             </div>
	              </div>
            </div>
		
		
		
		</div>	
	</div>
</div>
</body>